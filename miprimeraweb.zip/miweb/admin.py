from django.contrib import admin
from .models import Factores, Sintomas

admin.site.register(Factores)

admin.site.register(Sintomas)