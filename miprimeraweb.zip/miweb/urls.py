from django.contrib import admin
from django.urls import path
from miweb import views


urlpatterns = [
    path('',views.index,name="index"),
    path('contacto/',views.contacto,name="contacto"),
    path('detalle/',views.detalle,name="detalle"),
    path('detalledos/',views.detalledos,name="detalledos")
    #path('admin/', admin.site.urls),
]
